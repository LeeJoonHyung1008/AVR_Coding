#include <avr/io.h>
#include <avr/interrupt.h>
#include "delay2.h"
#include "LED.h"
#include "switch.h"

int mode = 0;
int function = 0;
int mode_state = 0;
int mode_state_key = 0;
int display = 0;
int display_for_INT = 0;

int servo_key = 0;
int per_angle = 0;
int per_angle_INT = 10;
int servo_angle = 0;

double Timer_cnt = 5;
int LED_Array[8] = {0xFE, 0xFD, 0xFB, 0xF7, 0xEF, 0xDF, 0xBF, 0x7F};
int cnt_for_mode1 = 0;

int a = 0;
int i = 0;
int j = 0;

SIGNAL (SIG_OVERFLOW1)
{
	if(PORTC == 0x00)
	{
		PORTC = 0xFF;
	}
	else if(PORTC == 0xFF)
	{
		PORTC = 0x00;
	}
	TCNT1=0;
}

SIGNAL(SIG_INTERRUPT0)
{
	if(mode_state == 'A')
	{		
		cnt_for_mode1++;
		if(cnt_for_mode1>7)
		{
			cnt_for_mode1 = 0;
		}
		PORTC = (LED_Array[cnt_for_mode1]);
	}
	else if(a == 2)
	{
		per_angle_INT++;
		if(per_angle_INT > 20)
		{
			per_angle_INT = 20;
		}
	}
}

SIGNAL(SIG_INTERRUPT1)
{
	if(mode_state == 'A')
	{
		cnt_for_mode1--;
		if(cnt_for_mode1<0)
		{
			cnt_for_mode1 = 7;
		}
		PORTC = (LED_Array[cnt_for_mode1]);
	}
	else if(a == 2)
	{
		Timer_cnt--;
		if(Timer_cnt < 1)
		{
			Timer_cnt = 1;
		}
	}
}


void main()
{
	IO_init();
	INT_init();
//	TIMER_init();
	while(1)
	{
		mode = KEYPAD();
		mode_state_key = mode;
//		SEG_ON('C',mode);
		if(mode == 1)
		{
			mode_state = 'A';
//			goto A;
		}		
		else if(mode == 2)
		{
			mode_state == 'B';
//			goto B;
		}

		while(mode == 1)
		{
				LED_ON(0x40);
				LED_OFF(0x80);
				display = KEYPAD2();
				PORTC = (LED_Array[display]);
				cnt_for_mode1 = display;

				a = KEYPAD();
				if(a == 2)
				{
				break;
				}
		}

		while(mode == 2)
		{
				LED_ON(0x80);
				LED_OFF(0x40);

		/*		per_angle = KEYPAD2();
				per_angle = per_angle * per_angle_INT;
				OCR1A = (540-350) * (per_angle / 180) + 350;
		*/
				for(int k=0; k<per_angle_INT; k++)
				{
					PORTC = 0x00;
					delay_us(per_angle_INT-i);
					PORTC = 0xFF;
					delay_us(i);
				}
				a = KEYPAD();
				if(a == 1)
				{
				break;
				}	
		}
		
	}
}	

