#include <avr/io.h>
#include <util/delay.h>
#include "UART.h"
#include "ADC.h"
#include "delay2.h"
#include "switch.h"

unsigned char a = 0, b = 0, c = 0;

void main()
{
	DDRC = 0xFF;
	PORTC = 0xFF;

	ADC_init();
	UART_init();
	while(1)
	{
		a = (read_adc(2)/1024.0)*8;
//		PORTC=0x00;
		putch(a);
		b = (read_adc(3)/1024.0)*8;	
//		PORTC=0xFF;
		putch(b);	
		c = SW(1);
		putch(c);
	}
}

//		getch(a);

	/*	a = (read_adc(2)/1024.0)*8;		// ADC to Joystick x values
		b = (read_adc(3)/1024.0)*8;		// ADC to Joystick y values
		c = (PIND & 0x20);	
	
		PORTA=~(1<<a);
		putch(a);
		putch(b);
		//putch(a);	*/
//	PORTA = b;
	
//	PORTA = c;	
