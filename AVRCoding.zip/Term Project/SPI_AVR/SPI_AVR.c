/*
ATmega128         ATmega128
Master            Slave
////////////////////////////
PB4---------------PB0(/SS)
PB1(SCK)----------PB1(SCK)
PB2(MOSI)---------PB2(MOSI)
PB3(MISO)---------PB3(MISO)
////////////////////////////
*/
 
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
 
#define SS_1     PORTB |= 0x10
#define SS_0     PORTB &=~0x10
 
volatile unsigned char rx_buf, count=0;
 
void SPI_Masterinit(void){
    DDRB|=0x17; 
    SPCR|=0xD1; 
    SS_1;
}
void SPI_TX(unsigned char data){
    SS_0; 
    SPCR&=~0x80; 
    SPDR=data; 
    while(!(SPSR&0x80)); 
    SPCR|=0x80;
}

ISR(SPI_STC_vect){
    rx_buf=SPDR;
    //SS_1;
}
 
int main(){
    DDRA = 0xFF;
    SPI_Masterinit();
    SREG = 0x80;
    while(1){
        SPI_TX(count++);
        PORTA=rx_buf;
        _delay_ms(100);
    }
}
 
