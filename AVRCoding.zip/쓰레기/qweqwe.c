#include <avr/io.h>
#include <delay.h>

flash char seg_part[10] = {0x3f, 0x06, 0x5b, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f};
					// 7 segment�� �ش��ϴ� ������ �迭�� �������ݴϴ�.
void Seg2_out(int);	// �� �ڸ� ���� ���
void main(void)
{
 int num=0;

 DDRB = 0xF0;
 DDRD = 0xF0;
 DDRG = 0x0F;
 PORTB = 0x0;
 PORTD = 0x0;
 while(1){
 Seg2_out(num);
 num++;
 if(num>99) num = 0;
 }
}

void Seg2_out(int num)
{
 int i, N10, N1;
 N10 = num / 10;
 N1 = num % 10;

 for(i=0;i<49;i++){
  PORTG = 0b00001000;
  PORTD = ((seg_pat[N1] & 0x0F) << 4) | (PORTD & 0x0F);
  PORTB = (seg_pat[N1] & 0x70) | (PORTB & 0x0F);
  delay_ms(10);
  PORTG = 0b00000100;
  PORTD = ((seg_pat[N1] & 0x0F) << 4) | (PORTD & 0x0F);
  PORTB = (seg_pat[N1] & 0x70) | (PORTB & 0x0F);
  delay_ms(10);
  }
}
