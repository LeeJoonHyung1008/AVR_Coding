#include <avr/io.h>

int count;

void main()
{
	int i;
		while(1){
			for(i=1;i<11;i++)
			{
			count = i;
			}
	}
}
