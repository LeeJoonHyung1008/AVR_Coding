 #include <avr/io.h>	

 int i_a;
 int i_b;
 int i_c;
char c_a;
char c_b;
char c_c;

void main()
{
	while(1)
	{
		i_a=0;
		i_b=0;
		i_c=0;
		c_a=0;
		c_b=0;
		c_c=0;

		i_a=127;
		i_b=128;
		i_c=i_a+i_b;
		 
		i_a=128;
		i_b=128;
		i_c=i_a+i_b;
		 
		c_a=127;
		c_b=128;
		c_c=c_a+c_b;
		 
		c_a=128;
		c_b=128;
		c_c=c_a+c_b;
		 
