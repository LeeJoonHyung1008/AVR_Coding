#include <avr/io.h>


void main()
{

DDRA = 0xFF;
PORTA = 0xF0;

}
