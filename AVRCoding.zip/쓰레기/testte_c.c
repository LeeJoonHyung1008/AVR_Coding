#include <avr/io.h>

int *a[100];

void main()
{
	int i;

	for(i=1;i<=100;i++)
	{
		a[i]=0x00+i;
		*a=(0x300+(i));
	}

}
