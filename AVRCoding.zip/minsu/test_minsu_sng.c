#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
char led[10]={0xC0,0xF9,0xA4,0xb0,0x99,0x92,0x83,0xD8,0x80,0x98};
void IO_init()
{  
   DDRA=0XFF;
   DDRC=0XFF;
   DDRD=0X00;
}
void INT_init()
{
   EICRA=0x00;
   EICRB=0x00;
   EIMSK=0x03;
   asm("SEI");      
}
int time_count=0,flag=0,sw_input=1;

SIGNAL(SIG_INTERRUPT0)
{
   if(flag==0)
   {
      sw_input=0;
      EICRA=0x07;//0111
       flag=1;
   }   
   else if(flag==1)
   {
      sw_input=1;
   }   
}
void main()
{
    IO_init();
    INT_init();
	int seg_1, seg_2;
   while(1)
   {
       if(sw_input==0)
      {   
        time_count++;
        seg_1=time_count/10;
		seg_2=time_count%10;  			
        _delay_ms(100);
        PORTA=~(~(led[seg_1])|0x80);
		PORTC=led[seg_2];    
      }
   }
}
