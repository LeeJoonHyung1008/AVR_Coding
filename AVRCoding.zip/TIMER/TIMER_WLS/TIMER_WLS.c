#include <avr/io.h>
#include <avr/interrupt.h>
#include "delay2.h"
#include "TIMER.h"
#include "LED.h"

int keypad();

int keypad()
{
PORTD=PORTD&0xFB;
delay_us(10);
if((PIND&0x20)==0)OCR1A=160;
if((PIND&0x40)==0)OCR1A=302;
if((PIND&0x80)==0)OCR1A=445;
PORTD|=~0xFB;

PORTD=PORTD&0xF7;
delay_us(10);
if((PIND&0x20)==0)OCR1A=207;   
if((PIND&0x40)==0)OCR1A=350;    
if((PIND&0x80)==0)OCR1A=493;    
PORTD|=~0xF7;

PORTD=PORTD&0xEF;
delay_us(10);
if((PIND&0x20)==0)OCR1A=255;  
if((PIND&0x40)==0)OCR1A=398;  
if((PIND&0x80)==0)OCR1A=540;    
PORTD|=~0xEF;
}

SIGNAL (SIG_OVERFLOW1)
{
TCNT1=0;
}

void main(){
IO_init();
TIMER_init();
  int data=0;
	while(1)
	{
 	data=keypad();
	}
}
