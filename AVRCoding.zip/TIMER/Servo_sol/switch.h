unsigned char SW(unsigned char pin);

int KEYPAD(void);
int keypad();
