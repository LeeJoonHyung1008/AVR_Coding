#include <avr/io.h>
#include <avr/interrupt.h>
#include "TIMER.h"
#include "LED.h"
#include "switch.h"

double degree=0;
int count=0;
int input_switch=0;

SIGNAL(SIG_OVERFLOW1)
{
TCNT1=0;
}

void main()
{

IO_init();
TIMER_init();
asm("sei");
	while(1)
	{
		count=KEYPAD();
		degree=count*20-20;
		OCR1A=(int)(225*(525-225)*degree/180);
		SEG_ON('A',count);

		input_switch=keypad();
	}
}
