#include <avr/io.h>
#include <avr/interrupt.h>
#include "TIMER.h"
#include "LED.h"

SIGNAL(SIG_OVERFLOW1)
{
	if(PORTA=0xFF)
	{
	PORTA=0x00;
	}
	else
	{
	PORTA=0xFF;
	}
	TCNT1=0x0BDB;	// 0x0BDB=3035 -> �ֱⰡ 1�ʰ� �� �� �ְ���.
} 

void main()
{
	IO_init();
	TIMER_init();
	while(1)
	{
	}
}



	
