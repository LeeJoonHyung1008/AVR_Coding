#include "INT.h"
#include <avr/interrupt.h>

void INT_init()
{
	EICRA=0x03;
	EICRB=0x00;
	EIMSK=0x03;
	asm("SEI");
}
