
void ADC_init();
