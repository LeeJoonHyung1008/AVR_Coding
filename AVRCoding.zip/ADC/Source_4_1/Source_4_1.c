#include <avr/io.h>
#include <avr/interrupt.h>

#define LED_PORT	PORTA

unsigned int ADC_Read;
unsigned char num=0, LED=1, i=0;
void IO_init();
void ADC_init();

void IO_init()
{
	PORTA=0xFF;
	DDRA=0xFF;
}

void ADC_init()
{
	ADMUX=0x40;
	ADCSRA=0b11001111;
}

SIGNAL(SIG_ADC)
{
	ADCSRA=ADCSRA|0x40;
	ADC_Read=ADCL+(ADCH<<8);
}

void main()
{
	IO_init();
	ADC_init();
	asm("sei");
	while(1)
	{
		num=ADC_Read/128;
		for(i=0;i<num+1;i++)
		{
			LED=LED*2;
		}
		LED_PORT= ~(LED-1);
		LED=1;
	}
}

