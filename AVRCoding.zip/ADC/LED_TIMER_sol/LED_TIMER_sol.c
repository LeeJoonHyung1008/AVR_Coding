#include <avr/io.h>
#include <avr/interrupt.h>
#include "LED.h"
#include "ADC.h"
#include "TIMER.h"
#include "delay2.h"

int i=0;
int flag=0;

SIGNAL(SIG_OVERFLOW1)
{
	flag=1;
	TCNT1=i;
}

void main()
{
	IO_init();
	ADC_init();
	TIMER_init_normal();
	asm("sei");
	while(1)
	{
		i=34286+(read_adc(0)*(15626/1024.0));
		if(flag==1)
		{
			LED_ON(0xFF);
			delay_ms(100);
			LED_OFF(0xFF);
			flag=0;
		}
	}
}

