

void TIMER_init();
void TIMER_init_normal();
