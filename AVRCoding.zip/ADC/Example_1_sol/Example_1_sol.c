#include <avr/io.h>
#include <avr/interrupt.h>
#include "LED.h"
#include "ADC.h"

int num=0;

void main()
{
	IO_init();
	ADC_init();
	asm("sei");
	while (1)
	{
		num=(int) read_adc(0)/10.24;
		SEG_ON('A',num/10);
		SEG_ON('C',num%10);

	}
}
