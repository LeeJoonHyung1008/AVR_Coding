#include <avr/io.h>
#include <avr/interrupt.h>

#define LED_PORT	PORTA
#define ADC_VREF_TYPE 0x40

unsigned char num=0, LED=1, i=0;
unsigned int read_adc(unsigned char adc_input);
void IO_init();
void ADC_init();

void IO_init()
{
	PORTA=0xFF;
	DDRA=0xFF;
}

void ADC_init()
{
	ADMUX=ADC_VREF_TYPE;
	ADCSRA=0x87;
}

unsigned int read_adc(unsigned char adc_input)
{
	unsigned int ANALOG_VALUE=0;
	ADMUX=adc_input|(ADC_VREF_TYPE&0xFF);
	ADCSRA |= 0x40;
	while((ADCSRA&0x10)==0);
	ADCSRA |= 0x10;
	ANALOG_VALUE=ADCL+(ADCH<<8);
	return ANALOG_VALUE;
}

void main()
{
	IO_init();
	ADC_init();
	asm("sei");
	while(1)
	{
		num=read_adc(0)/128;
		for(i=0;i<num+1;i++)
		{
			LED=LED+2;
		}
		LED_PORT= ~(LED-1);
		LED=1;
	}
}
