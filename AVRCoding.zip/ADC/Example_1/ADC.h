void ADC_init();
unsigned int read_adc(unsigned char adc_input);
