
void INT_init();
