#include <avr/io.h>
#include "LED.h"

void IO_init()
{
	DDRB=0xFF;
	DDRA=0xFF;
}


