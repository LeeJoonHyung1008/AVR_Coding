#include <avr/io.h>
#include <avr/interrupt.h>
#include "LED.h"
#include "TIMER.h"
#include "ADC.h"

double deg=0;

SIGNAL(SIG_OVERFLOW1)
{
	TCNT1=1;
}

void main()
{
	IO_init();
	ADC_init();
	TIMER_init();
	asm("sei");
	
	while(1)
	{
		deg=read_adc(0)*(180.0/1024.0);
		OCR1A=(int)(225+(525-225)*deg/180.0);
	}
}
