#include <avr/io.h>
#include <util/delay.h>
#include "UART.h"

void main()
{
	char a = '0';
	char b = 'A';
	char c = 'a';
	UART_init();
	while(1)
	{
		putch(a);
		putch(b);
		putch(c);

	}
}
// 100000 / 26 = baud rate = 38400 
