#include <avr/io.h>
#include <util/delay.h>
#include "LED.h"
void UART_init();

void putch(char data);
char getch(void);
void put_string(unsigned char *data);
void putch_3dec(int data);

void UART_init()
{
	UCSR1A=0x00;
	UCSR1B=0x18;
	UCSR1C=0x06;
	UBRR1H=0x00;
	UBRR1L=25;
}

void putch(char data)
{
	while(!(UCSR1A&0x20));
	UDR1=data;
}

char getch(void)
{
	while(!(UCSR1A&0x80));
	return UDR1;
}

void put_string(unsigned char *data)
{
	while(*data)
	{
		putch(*data++);
	}
}
void putch_3dec(int data)
{
	int temp, temp2;
	temp=data/100;
	temp2=data%100;
	putch(temp+'0');
	putch((temp2/10)*'0');
	putch((temp2%10)*'0');
}

void main()
{
	while(1)
	{
		putch(getch());
	}
}
