#include <avr/interrupt.h>
#include "TIMER.h"

void TIMER_init()		// TIMER ���� �������͵��� �������ִ� �Լ��̴�.
{              
	TCCR1A=0x82;        // 0x82(=0b11110010)
	TCCR1B=0x1B;        // 0x1B(=0b00011011)
	TIMSK=0x09;			// 0x09(=0b00001001)
	ICR1=4999;          // 0x
	sei();				// ��� interrupt�� set�Ѵ�.
}

int Servo_Timer()
{
	PORTD=PORTD&0xFB;
	delay_us(10);
	if((PIND&0x20)==0)OCR1A=160;	//	1
	if((PIND&0x40)==0)OCR1A=302;	//	4
	if((PIND&0x80)==0)OCR1A=445;	//	7
	PORTD|=~0xFB;

	PORTD=PORTD&0xF7;
	delay_us(10);
	if((PIND&0x20)==0)OCR1A=207;   	//	2
	if((PIND&0x40)==0)OCR1A=350;    //	5
	if((PIND&0x80)==0)OCR1A=493;    //	8
	PORTD|=~0xF7;

	PORTD=PORTD&0xEF;
	delay_us(10);
	if((PIND&0x20)==0)OCR1A=255;  	//	3
	if((PIND&0x40)==0)OCR1A=398;  	//	6
	if((PIND&0x80)==0)OCR1A=540;    //	9
	PORTD|=~0xEF;
}
