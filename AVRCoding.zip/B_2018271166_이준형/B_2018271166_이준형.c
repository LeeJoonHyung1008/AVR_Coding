#include <avr/io.h>
#include <avr/interrupt.h>
#include "LED.h"
#include "delay2.h"
#include "INT.h"
#include "switch.h"
#include "UART.h"
#include "ADC.h"

int mode = 0;


void main()
{
	UART_init();
	putch(getch());
	if(UDR0 == 7)
	{
	LED_ON(7);
	}


}
