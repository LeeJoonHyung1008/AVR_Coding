
void UART_init();
void putch(char data);
char getch();
void put_string(unsigned char *data);
void putch_3dec(int data);
