unsigned char SW(unsigned char pin);
unsigned char SW_PORTB(unsigned char pin);
int KEYPAD(void);
