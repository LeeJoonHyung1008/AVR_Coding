#include<avr/io.h>
#include <avr/interrupt.h>
#include"TIMER.h"
#include"LED.h"
#include"switch.h"
#include"int.h"
#include"ADC.h"

int esw=1;
int mode = 0;
int c=0;
double deg=0;
int cnt=0;
int d=10;
int a=0;

SIGNAL(SIG_OVERFLOW1)
{
	TCNT1=0;
}

SIGNAL(SIG_INTERRUPT0)
	{
	if(mode ==1)
	{
	c--;
	if(c<0)
	{
	c=9;
	}
	SEG_ON('C',c);
	}
	if(mode==2)
	{
	d--;
	if(d<5)
	{
	d=5;
	}
	}
	}

SIGNAL(SIG_INTERRUPT1)
	{
	if(mode==1)
	{
	c++;
	if(c>9)
	{
	c=0;
	}
	SEG_ON('C',c);
	}
	if(mode==2)
	{
	d++;
	if(d>20)
	{
	d=20;
	}
	}
	}



void main()
{  
	
	IO_init();
	TIMER_init();
	INT_init();
	asm("sei");
	while(1)
	{  
	a = KEYPAD();

	if(a==1)
	{
	mode =1;
	LED_OFF(0xFF);
	LED_ON(0x40);

	}
	if(a==2)
	{
	PORTC=0xFF;
	mode =2;	
	LED_OFF(0xFF);
	LED_ON(0x80);
	}


	if(mode==2)
	{
	
	deg = cnt*d;
	OCR1A=(int)(225+(525-225)*deg/180);
	}
	}
	
	if(mode==1)
	{
	if(a>6)
	{
	c=a-6;
	SEG_ON('C',c);
	}
	if((a<7)&&(a>3))
	{
	c=a;
	SEG_ON('C',c);
	}


	

}
}
