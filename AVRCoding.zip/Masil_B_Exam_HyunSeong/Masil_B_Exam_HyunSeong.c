#include <avr/io.h>
#include <avr/interrupt.h>

#include "LED.h"

#include "delay2.h"
#include "ADC.h"
#include "switch.h"


double deg = 0;
// base servo varaible
int cnt =0;
unsigned char sw;
int a;
int chk ;
int temp;

void INT_init()
{
	EICRA= 0x0A;
	EICRB = 0x00;
	EIMSK = 0x03;
	asm("SEI");
}

SIGNAL(SIG_OVERFLOW1)
{
	TCNT1 = 0;
}

SIGNAL(SIG_INTERRUPT0)
{	
		sei();
		cnt++;
			if(a == 7)
		{
			if (cnt <8)
			cnt = 0;
		}
		else if(a == 8)
		{
			if (cnt <7)
			cnt = 0;
		}
		else if(a == 9)
		{
			if (cnt <6)
			cnt = 0;
		}
		else if(a == 4)
		{
			if (cnt <5)
			cnt = 0;
		}
		else if(a == 5)
		{
			if (cnt <4)
			cnt = 0;
		}
		else if(a == 3)
		{
			if (cnt <6)
			cnt = 0;
		}
		SEG_ON('C', a+cnt);
	
}

SIGNAL(SIG_INTERRUPT1)
{
	sei();
	
		cnt--;
		if(a == 7)
		{
			if (cnt <8)
			cnt = 0;
		}
		else if(a == 8)
		{
			if (cnt <7)
			cnt = 0;
		}
		else if(a == 9)
		{
			if (cnt <6)
			cnt = 0;
		}
		else if(a == 4)
		{
			if (cnt <5)
			cnt = 0;
		}
		else if(a == 5)
		{
			if (cnt <4)
			cnt = 0;
		}
		else if(a == 3)
		{
			if (cnt <6)
			cnt = 0;
		}
		SEG_ON('C', a+cnt);
	
}

void main()
{
	IO_init();
	INT_init();
	TIMER_init();
	ADC_init();

	while(1)
	{
	
		a = KEYPAD();
		while(a == 1)
		{	
			sei();
			while(1)
			{
			LED_ON(0x40);
			LED_OFF(0x80);
			int mode;
			mode = KEYPAD();
			LED_ON(0x40);

			if(mode ==4){
			SEG_ON('C', mode);
			cnt = 0;} 
			else if(mode ==5){
			SEG_ON('C',mode);
			cnt=0;}
			else if(mode ==6){
			cnt = 0;
			SEG_ON('C', mode);}
			else if(mode ==1){
			SEG_ON('C', mode);
			cnt = 0;}
			else if(mode ==2){
			SEG_ON('C', mode);
			cnt = 0;}
			else if(mode ==3){
			SEG_ON('C', mode);
			cnt = 0;}

			
	

			a = KEYPAD();
			if (a==2)
			break;
			}
			break;
		}	

		while( a == 2)
		{
			LED_OFF(0x40);
			LED_ON(0x80);
			cli();
			while(1){
			int b ;
			b = KEYPAD();
			PORTC = b;	/*
			if(b==7)
			{
				LED_ON(1);
				OCR1A  = 225;
			}
			else if(b==8)
			{
				OCR1A = 245;
			}
			else if(b == 9)
			{
				OCR1A = 265;
			}
			else if(b == 4)
			{
				OCR1A= 285;
			}
			else if( b==5)
			{
				OCR1A = 305;
			}
			else if(b == 6)
			{
				OCR1A= 325;
			}	*/
	

			a = KEYPAD();
			if( a == 1)
			break;
			}
			break;
		}
	}
}
