#include<avr/io.h>
#include<avr/interrupt.h>
#define LED_PORT PORTA

void IO_init();
void INT_init();
void TIMER_init();

unsigned int count=0;
unsigned char count_on=0;

void IO_init()
{
	DDRA = 0XFF;
	PORTA = 0XFF;
}

void INT_init()
{
	EICRA=0X02;
	EICRB=0X00;
	EIMSK=0X03;
	sei();
}
void TIMER_init()
{
	TCCR1A=0X00;
	TCCR1B=0X04;
	TIMSK=0X04;
	TCNT1 = 0XBDB;
}

SIGNAL (SIG_OVERFLOW1){
	cli();
	if(count_on){
	count++;
	}
	TCNT1 = 0xBDB;
	sei();
}

SIGNAL (SIG_INTERRUPT0){
	if(count_on){
		PORTA = count;
		EICRA=0X02;
		count = 0;
		count_on =0;
	}
	else{
		EICRA=0X03;
		count_on =1;
	}
}

SIGNAL(SIG_INTERRUPT1){
	LED_PORT = 0xff;
	count=0;
}

void main(){
	IO_init();
	INT_init();
	TIMER_init();

	while(1)
	{
	}
}
