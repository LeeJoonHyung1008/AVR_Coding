void delay_us(unsigned int time);
void delay_ms(unsigned int time);
