
#include <avr/io.h>

void main()
{
	DDRA = 0xFF;
	PORTA = 0x00;
	while(1)
	{

	}

}
