#include<avr/io.h>        
#include "LED.h"
#include "delay2.h"
       
unsigned char SW(unsigned char pin)
{
	unsigned char sw_input;
	sw_input = PIND;
	sw_input &= pin;
	return sw_input;
}

unsigned char A='A';
unsigned char C='C';

void main()
{
	IO_init();

	while(1)
	{
		if(SW(1)==0)
		{
			SEG_ON(C,1);
			SEG_ON(A,9);
		}
		else if (SW(2)==0)
		{
			SEG_ON_two_numbers_all_in_one(47);		
		}
		else
		{
			PORTA=0xFF;
			PORTC=0xFF;
		}
	}
}
