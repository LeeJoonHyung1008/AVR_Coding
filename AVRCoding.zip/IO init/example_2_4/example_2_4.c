#include<avr/io.h>       //������� ����
#include "LED.h"
#include "delay2.h"

unsigned char SW(unsigned char pin)
{
	unsigned char sw_input;
	sw_input=PIND;
	sw_input&=pin;
	return sw_input;
}

unsigned char A = 'A';
unsigned char C = 'C';


void main()
{
IO_init();
while(1)
{
SEG_ON(C,7);
SEG_ON(A,5);
}
}
