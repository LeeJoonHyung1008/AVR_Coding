#include <avr/io.h>     
#include "LED.h"
#include "delay2.h"  

unsigned char SW(unsigned char pin)
{
	unsigned char sw_input;
	sw_input = PIND;
	sw_input &= pin;
	return sw_input;
}

void main()
{
	IO_init();

	while(1)
	{
		if(SW(1)==0)
		{
		LED_ON(0x0F);
		}
		else if(SW(2)==0)
		{
		LED_ON(0xF0);
		}
		else
		{
		LED_OFF(0xFF);
		}
	}
}
