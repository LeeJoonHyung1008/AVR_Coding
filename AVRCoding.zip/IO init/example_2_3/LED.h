#define LED_PORT PORTA
#define SEG_PORT PORTC

void IO_init();

void LED_ON(unsigned char pin);
void LED_OFF(unsigned char pin);
