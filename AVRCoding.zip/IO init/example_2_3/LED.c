#include <avr/io.h>
#include "LED.h"

void IO_init()
{
	PORTA=0xFF;
	DDRA=0xFF;
	PORTC=0xFF;
	DDRC=0xFF;
	DDRD=0x1C;
}

void LED_ON(unsigned char pin)
{
//	pint = -pin;	// �Է¹��� pin�� ���� �����ش�.
//	PORTA = PORTA & pin;
	PORTA &= (~pin);
}

void LED_OFF(unsigned char pin)
{
	PORTA |= (pin);
}
