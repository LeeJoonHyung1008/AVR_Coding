#include<avr/io.h>
#include<util/delay.h>
 char array[11]={0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xD8, 0x80, 0x98,0xFF};
int keypad()
{
int flag=10;
PORTD=PORTD&0x03;
_delay_us(10);
if((PIND&0x01)==0)PORTA=array[0];
PORTD|=~0X03;

PORTD=PORTD&0xFB;
_delay_us(10);
if((PIND&0x20)==0)PORTA=array[1];
if((PIND&0x40)==0)PORTA=array[4];
if((PIND&0x80)==0)PORTA=array[7];
PORTD|=~0xFB;

PORTD=PORTD&0xF7;
_delay_us(10);
if((PIND&0x20)==0)PORTA=array[2];   
if((PIND&0x40)==0)PORTA=array[5];    
if((PIND&0x80)==0)PORTA=array[8];    
PORTD|=~0xF7;

PORTD=PORTD&0xEF;
_delay_us(10);
if((PIND&0x20)==0)PORTA=array[3];  
if((PIND&0x40)==0)PORTA=array[6];  
if((PIND&0x80)==0)PORTA=array[9];    
PORTD|=~0xEF;





return flag;
}
void main()
{
  
   int data=0;
       DDRD=0x1C;
      DDRA=0xFF;
	  
  while(1){
    data=keypad();
  // PORTA=array[data];     
      
   }

}
