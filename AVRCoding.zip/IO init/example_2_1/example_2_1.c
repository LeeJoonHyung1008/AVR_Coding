#include <avr/io.h>                       
#define LED_PORT PORTA              // PORTA�� LED_PORT�� ����


void main()
{
	DDRA=0xFF;
	DDRC=0xFF;
   PORTA=0x00;
   PORTC=0x00;
}
