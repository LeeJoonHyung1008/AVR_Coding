#include <avr/io.h>
#include <avr/interrupt.h>
#define LED_PORT PORTA

void delay_us(unsigned int time);
void delay_ms(unsigned int time);
void IO_init();
void INT_init();

void delay_us(unsigned int time){
	unsigned int ns_i;
	for(ns_i=0;ns_i<time;ns_i++){
		asm("nop");
	}
}

void delay_ms(unsigned int time){
	unsigned int ns_i;
	for(ns_i=0;ns_i<time;ns_i++){
		delay_us(1000/14);
	}
}

void IO_init()
{
	DDRA=0xFF;
}
void INT_init()
{
	EICRA=0x03;
	EICRB=0x00;
	EIMSK=0x01;
	asm("SEI");
}
SIGNAL (SIG_INTERRUPT0)
{
	LED_PORT = 0xF0;
	delay_ms(500);
}

void main(){
	unsigned char i;
	IO_init();
	INT_init();
		
	while(1){
		for(i=0;i<8;i++){
			LED_PORT =~(0x01<<i);
			delay_ms(500);
		}
	}
}
