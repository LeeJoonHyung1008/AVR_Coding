#include <avr/io.h>
#include <avr/interrupt.h>
#include "LED.h"
#include "delay2.h"
#include "switch.h"
#include "INT.h"

SIGNAL(SIG_INTERRUPT0)
{
	LED_PORT=0xF0;
	delay_ms(500);
}

void main()
{
	unsigned char i;

	IO_init();
	INT_init();

	while(1)
	{
		for(i=0;i<8;i++)
		{
			LED_PORT=~(0x01<<i);
			delay_ms(500);
		}
	}
}
