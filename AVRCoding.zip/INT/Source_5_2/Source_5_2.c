#include <avr/io.h>
#include <avr/interrupt.h>

#define LED_PORT	PORTA
#define REF_TCNT_MAX 0
#define REF_TCNT_DEF 1
#define REF_TCNT_MIN 2

void delay_us(unsigned int time);
void delay_ms(unsigned int time);
void IO_init();
void INT_init();

unsigned char ref_tcnt,ref_tcnt_limit[3]={30,15,1};

void delay_us(unsigned int time){
	unsigned int ns_i;
	for(ns_i=0;ns_i<time;ns_i++){
		asm("nop");
	}
}
void delay_ms(unsigned int time){
	unsigned int ns_i;
	for(ns_i=0;ns_i<time;ns_i++){
		delay_us(1000/14);
	}
}

void IO_init()
{
	DDRA=0xFF;
}
void INT_init()
{
	EICRA=0x0A;
	EICRB=0x00;
	EIMSK=0x03;
	asm("SEI");
}

SIGNAL(SIG_INTERRUPT0)
{
	if(ref_tcnt_limit[REF_TCNT_MAX]>ref_tcnt)
	{
		ref_tcnt++;
	}
}
SIGNAL(SIG_INTERRUPT1)
{
	if(ref_tcnt_limit[REF_TCNT_MIN]<ref_tcnt)
	{
		ref_tcnt--;
	}
}

void main()
{
	unsigned char i, ref_delay, tcnt;
	ref_tcnt=ref_tcnt_limit[REF_TCNT_DEF];
	ref_delay=20;

	IO_init();
	INT_init();
	while(1)
	{
		for(i=1;i<ref_delay;i++)
		{
			for(tcnt=0;tcnt<ref_tcnt;tcnt++)
			{
				LED_PORT=0xF3;
				delay_ms(ref_delay-i);
				LED_PORT=0x3F;
				delay_ms(i);
			}
		}
	}
}
