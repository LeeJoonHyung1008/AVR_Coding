#define LED_PORT PORTA
#define SEG_PORT PORTC

void IO_init();
